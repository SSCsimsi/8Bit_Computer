*PADS-LIBRARY-PART-TYPES-V9*

CY74FCT163CTSOC SOIC127P1030X265-16N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.19.00.43
"Mouser Part Number" 595-CY74FCT163CTSOC
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=595-CY74FCT163CTSOC
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" CY74FCT163CTSOC
"Description" Counter ICs Synch 4B Bin Counter
"Datasheet Link" http://www.ti.com/lit/ds/symlink/cy54fct163t.pdf
"Geometry.Height" 2.65mm
GATE 1 16 0
CY74FCT163CTSOC
1 0 U \SR
2 0 U CP
3 0 U P0
4 0 U P1
5 0 U P2
6 0 U P3
7 0 U CEP
8 0 U GND
16 0 U VCC
15 0 U TC
14 0 U Q0
13 0 U Q1
12 0 U Q2
11 0 U Q3
10 0 U CET
9 0 U \PE

*END*
*REMARK* SamacSys ECAD Model
1582181/1410301/2.50/16/3/Integrated Circuit
