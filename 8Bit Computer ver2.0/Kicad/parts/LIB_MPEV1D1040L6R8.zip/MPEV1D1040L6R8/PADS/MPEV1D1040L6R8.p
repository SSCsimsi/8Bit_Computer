*PADS-LIBRARY-PART-TYPES-V9*

MPEV1D1040L6R8 INDPM108100X400N I CAP 7 1 0 0 0
TIMESTAMP 2025.10.28.21.57.58
"Mouser Part Number" 80-MPEV1D1040L6R8
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KEMET/MPEV1D1040L6R8?qs=CiayqK2gdcKA1UFpsymDIg%3D%3D
"Manufacturer_Name" KEMET
"Manufacturer_Part_Number" MPEV1D1040L6R8
"Description" KEMET, MPEV, Power, 6.8 uH, 20%, 180C, -55C, 4340, 8.3 A, 24.1 mOhms, 14 MHz, 500, 10.8mm, 11.1mm, 10mm, 10.2mm, 4mm, 4mm
"Datasheet Link" https://content.kemet.com/datasheets/KEM_L9016_MPEV.pdf
"Geometry.Height" 4mm
GATE 1 2 0
MPEV1D1040L6R8
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
14965836/1410301/2.50/2/2/Capacitor
