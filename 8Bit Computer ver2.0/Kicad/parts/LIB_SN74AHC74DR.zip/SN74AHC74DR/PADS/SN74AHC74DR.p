*PADS-LIBRARY-PART-TYPES-V9*

SN74AHC74DR SOIC127P600X175-14N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.20.03.06
"Mouser Part Number" 595-SN74AHC74DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AHC74DR?qs=st7IWvlL5%2FgP9OJq63EsFQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHC74DR
"Description" Dual Positive-Edge-Triggered D-Type Flip-Flops With Clear and Preset
"Datasheet Link" http://www.ti.com/lit/gpn/sn74ahc74
"Geometry.Height" 1.75mm
GATE 1 14 0
SN74AHC74DR
1 0 U 1\CLR
2 0 U 1D
3 0 U 1CLK
4 0 U 1\PRE
5 0 U 1Q
6 0 U 1\Q
7 0 U GND
14 0 U VCC
13 0 U 2\CLR
12 0 U 2D
11 0 U 2CLK
10 0 U 2\PRE
9 0 U 2Q
8 0 U 2\Q

*END*
*REMARK* SamacSys ECAD Model
327949/1410301/2.50/14/0/Integrated Circuit
