*PADS-LIBRARY-PART-TYPES-V9*

M29F800FT55N3E2 SOP50P2000X120-48N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.19.07.14
"Mouser Part Number" 913-M29F800FT55N3E2
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Alliance-Memory/M29F800FT55N3E2?qs=vmHwEFxEFR9Aw9aI%2FlWRzQ%3D%3D
"Manufacturer_Name" Alliance Memory
"Manufacturer_Part_Number" M29F800FT55N3E2
"Description" NOR Flash NOR Flash(Micron) , PARALLEL, 8M , TSOP 48PIN, 55ns, -40-+125C, TOP, Tray
"Datasheet Link" https://www.alliancememory.com/wp-content/uploads/pdf/micron/M29FxxFT_FB.pdf
"Geometry.Height" 1.2mm
GATE 1 48 0
M29F800FT55N3E2
1 0 U A15
2 0 U A14
3 0 U A13
4 0 U A12
5 0 U A11
6 0 U A10
7 0 U A9
8 0 U A8
9 0 U NC_1
10 0 U NC_2
11 0 U WE#
12 0 U RP#
13 0 U NC_3
14 0 U NC_4
15 0 U R/B#
16 0 U A18
17 0 U A17
18 0 U A7
19 0 U A6
20 0 U A5
21 0 U A4
22 0 U A3
23 0 U A2
24 0 U A1
48 0 U A16
47 0 U BYTE#
46 0 U VSS_2
45 0 U DQ15A-1
44 0 U DQ7
43 0 U DQ14
42 0 U DQ6
41 0 U DQ13
40 0 U DQ5
39 0 U DQ12
38 0 U DQ4
37 0 U VCC
36 0 U DQ11
35 0 U DQ3
34 0 U DQ10
33 0 U DQ2
32 0 U DQ9
31 0 U DQ1
30 0 U DQ8
29 0 U DQ0
28 0 U OE#
27 0 U VSS_1
26 0 U CE#
25 0 U A0

*END*
*REMARK* SamacSys ECAD Model
12046256/1410301/2.50/48/3/Integrated Circuit
