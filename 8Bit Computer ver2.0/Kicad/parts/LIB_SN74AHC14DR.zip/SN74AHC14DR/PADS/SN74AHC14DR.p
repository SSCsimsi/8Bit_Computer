*PADS-LIBRARY-PART-TYPES-V9*

SN74AHC14DR SOIC127P600X175-14N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.18.58.47
"Mouser Part Number" 595-SN74AHC14DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AHC14DR?qs=ZA235jQDfbrd%252BwhwnzLskw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHC14DR
"Description" Hex Schmitt-Trigger Inverters
"Datasheet Link" http://www.ti.com/lit/gpn/sn74ahc14
"Geometry.Height" 1.75mm
GATE 1 14 0
SN74AHC14DR
1 0 U 1A
2 0 U 1Y
3 0 U 2A
4 0 U 2Y
5 0 U 3A
6 0 U 3Y
7 0 U GND
14 0 U VCC
13 0 U 6A
12 0 U 6Y
11 0 U 5A
10 0 U 5Y
9 0 U 4A
8 0 U 4Y

*END*
*REMARK* SamacSys ECAD Model
6363/1410301/2.50/14/3/Integrated Circuit
