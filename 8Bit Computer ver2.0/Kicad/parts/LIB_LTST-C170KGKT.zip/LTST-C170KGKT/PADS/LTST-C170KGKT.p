*PADS-LIBRARY-PART-TYPES-V9*

LTST-C170KGKT LEDC2012X110N I DIO 7 1 0 0 0
TIMESTAMP 2025.10.27.15.46.13
"Mouser Part Number" 859-LTST-C170KGKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Lite-On/LTST-C170KGKT?qs=o1ACzGp%252Bek3F8d3sLmVFGg%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C170KGKT
"Description" LED,SMD,0805,Green,35mcd,130deg Lite-On LTST-C170KGKT, CHIPLED 0805 Series Green LED, 571 nm 2012 (0805), Rectangle Lens SMD package
"Datasheet Link" 
"Geometry.Height" 1.1mm
GATE 1 2 0
LTST-C170KGKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
279694/1410301/2.50/2/4/LED
