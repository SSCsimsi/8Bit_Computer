*PADS-LIBRARY-PART-TYPES-V9*

M20-7910842R M207910842R I CON 7 1 0 0 0
TIMESTAMP 2025.10.25.11.42.43
"Mouser Part Number" 855-M20-7910842R
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-7910842R?qs=k41KVqW3ympJ6ZCQNkwKKw%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-7910842R
"Description" 2.54mm (0.1") Pitch SIL Horizontal SMT Socket Assembly, selective gold + tin (Tape & Reel packing), 8 contacts
"Datasheet Link" https://www.digikey.ph/en/products/detail/harwin-inc/M20-7910842R/6559285?msockid=39f1ec84d77b6f4428b7f904d6676eed
"Geometry.Height" 2.65mm
GATE 1 8 0
M20-7910842R
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8

*END*
*REMARK* SamacSys ECAD Model
724159/1410301/2.50/8/2/Connector
