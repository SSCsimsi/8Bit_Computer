*PADS-LIBRARY-PART-TYPES-V9*

LTST-C170KRKT LEDC2012X120N I DIO 7 1 0 0 0
TIMESTAMP 2025.10.27.15.46.17
"Mouser Part Number" 859-LTST-C170KRKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/LITEON/LTST-C170KRKT?qs=NUb82WqeCyrVOID%2Fxt4rgA%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C170KRKT
"Description" Standard LEDs - SMD Red Clear 631nm
"Datasheet Link" https://componentsearchengine.com/Datasheets/1/LTST-C170KRKT.pdf
"Geometry.Height" 1.2mm
GATE 1 2 0
LTST-C170KRKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
262224/1410301/2.50/2/4/LED
