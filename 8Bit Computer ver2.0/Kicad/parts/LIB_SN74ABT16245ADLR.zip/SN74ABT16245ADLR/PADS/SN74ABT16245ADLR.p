*PADS-LIBRARY-PART-TYPES-V9*

SN74ABT16245ADLR SOP64P1035X279-48N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.11.22.41.06
"Mouser Part Number" 595-SN74ABT16245ADLR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74ABT16245ADLR?qs=vxEfx8VrU7BbFiTJWgbLWw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74ABT16245ADLR
"Description" Texas Instruments SN74ABT16245ADLR, Dual, Bus Transceiver, 16-Bit Non-Inverting TTL, 5V, 48-Pin SSOP
"Datasheet Link" http://www.ti.com/lit/gpn/sn74abt16245a
"Geometry.Height" 2.79mm
GATE 1 48 0
SN74ABT16245ADLR
1 0 U 1DIR
2 0 U 1B1
3 0 U 1B2
4 0 U GND_1
5 0 U 1B3
6 0 U 1B4
7 0 U VCC_1
8 0 U 1B5
9 0 U 1B6
10 0 U GND_2
11 0 U 1B7
12 0 U 1B8
13 0 U 2B1
14 0 U 2B2
15 0 U GND_3
16 0 U 2B3
17 0 U 2B4
18 0 U VCC_2
19 0 U 2B5
20 0 U 2B6
21 0 U GND_4
22 0 U 2B7
23 0 U 2B8
24 0 U 2DIR
48 0 U 1\OE
47 0 U 1A1
46 0 U 1A2
45 0 U GND_8
44 0 U 1A3
43 0 U 1A4
42 0 U VCC_4
41 0 U 1A5
40 0 U 1A6
39 0 U GND_7
38 0 U 1A7
37 0 U 1A8
36 0 U 2A1
35 0 U 2A2
34 0 U GND_6
33 0 U 2A3
32 0 U 2A4
31 0 U VCC_3
30 0 U 2A5
29 0 U 2A6
28 0 U GND_5
27 0 U 2A7
26 0 U 2A8
25 0 U 2\OE

*END*
*REMARK* SamacSys ECAD Model
415966/1410301/2.50/48/3/Integrated Circuit
