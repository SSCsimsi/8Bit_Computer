*PADS-LIBRARY-PART-TYPES-V9*

SN74LVC1G86DBVR SOT95P280X145-5N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.11.18.37.41
"Mouser Part Number" 595-SN74LVC1G86DBVR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74LVC1G86DBVR?qs=d9gICRQKuCcyH%2F0J6yE9tQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74LVC1G86DBVR
"Description" Single 2-Input Exclusive-OR Gate
"Datasheet Link" http://www.ti.com/lit/ds/symlink/sn74lvc1g86.pdf
"Geometry.Height" 1.45mm
GATE 1 5 0
SN74LVC1G86DBVR
1 0 L A
2 0 L B
3 0 G GND
4 0 S Y
5 0 P VCC

*END*
*REMARK* SamacSys ECAD Model
237610/1410301/2.50/5/3/Integrated Circuit
