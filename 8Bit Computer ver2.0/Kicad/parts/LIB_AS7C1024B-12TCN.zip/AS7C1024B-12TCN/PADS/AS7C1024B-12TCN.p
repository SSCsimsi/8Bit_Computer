*PADS-LIBRARY-PART-TYPES-V9*

AS7C1024B-12TCN SOP50P2000X120-32N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.11.10.05.27
"Mouser Part Number" 913-AS7C1024B-12TCN
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Alliance-Memory/AS7C1024B-12TCN?qs=E5c5%252Bmu3i39p9b7hUnTiBw%3D%3D
"Manufacturer_Name" Alliance Memory
"Manufacturer_Part_Number" AS7C1024B-12TCN
"Description" Industrial and commercial temperatures  Organization: 131,072 words x 8 bits  High speed  10/12/15/20 ns address access time  5/6/7/8 ns output enable access time  Low power consumption: ACTIVE  605 mW / max @ 10 ns  Low power consumption: STANDBY  55 mW / max CMOS  Easy memory expansion with CE1, CE2, OE inputs  TTL/LVTTL-compatible, three-state I/O 32-pin JEDEC standard packages
"Datasheet Link" https://mm.digikey.com/Volume0/opasdata/d220001/medias/docus/7135/PdfFile_316396.pdf
"Geometry.Height" 1.2mm
GATE 1 32 0
AS7C1024B-12TCN
1 0 U A11
2 0 U A9
3 0 U A8
4 0 U A13
5 0 U \WE
6 0 U CE2
7 0 U A15
8 0 U VCC
9 0 U NC
10 0 U A16
11 0 U A14
12 0 U A12
13 0 U A7
14 0 U A6
15 0 U A5
16 0 U A4
32 0 U \OE
31 0 U A10
30 0 U \CE1
29 0 U I/O7
28 0 U I/O6
27 0 U I/O5
26 0 U I/O4
25 0 U I/O3
24 0 U GND
23 0 U I/O2
22 0 U I/O1
21 0 U I/O0
20 0 U A0
19 0 U A1
18 0 U A2
17 0 U A3

*END*
*REMARK* SamacSys ECAD Model
804180/1410301/2.50/32/3/Integrated Circuit
