*PADS-LIBRARY-PART-TYPES-V9*

SN74ABT574ADWR SOIC127P1030X265-20N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.20.03.02
"Mouser Part Number" 595-SN74ABT574ADWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74ABT574ADWR?qs=nMmhAzRCgdCWNOUsuPi1DA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74ABT574ADWR
"Description" Texas Instruments SN74ABT574ADWR, D Type Bus Interface Flip Flop, 3-State, 4.5  5.5 V, 20-Pin SOIC
"Datasheet Link" http://www.ti.com/lit/gpn/sn74abt574a
"Geometry.Height" 2.65mm
GATE 1 20 0
SN74ABT574ADWR
1 0 U \OE
2 0 U 1D
3 0 U 2D
4 0 U 3D
5 0 U 4D
6 0 U 5D
7 0 U 6D
8 0 U 7D
9 0 U 8D
10 0 U GND
20 0 U VCC
19 0 U 1Q
18 0 U 2Q
17 0 U 3Q
16 0 U 4Q
15 0 U 5Q
14 0 U 6Q
13 0 U 7Q
12 0 U 8Q
11 0 U CLK

*END*
*REMARK* SamacSys ECAD Model
415992/1410301/2.50/20/3/Integrated Circuit
