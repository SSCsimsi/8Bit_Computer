*PADS-LIBRARY-PART-TYPES-V9*

SN74AHC540DWR SOIC127P1030X265-20N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.25.11.42.23
"Mouser Part Number" 595-SN74AHC540DWR
"Mouser Price/Stock" https://www.mouser.com/Search/Refine.aspx?Keyword=595-SN74AHC540DWR
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHC540DWR
"Description" Octal Buffers/Drivers With 3-State Outputs
"Datasheet Link" http://www.ti.com/lit/gpn/sn74ahc540
"Geometry.Height" 2.65mm
GATE 1 20 0
SN74AHC540DWR
1 0 U \OE1
2 0 U A1
3 0 U A2
4 0 U A3
5 0 U A4
6 0 U A5
7 0 U A6
8 0 U A7
9 0 U A8
10 0 U GND
20 0 U VCC
19 0 U \OE2
18 0 U Y1
17 0 U Y2
16 0 U Y3
15 0 U Y4
14 0 U Y5
13 0 U Y6
12 0 U Y7
11 0 U Y8

*END*
*REMARK* SamacSys ECAD Model
752066/1410301/2.50/20/3/Integrated Circuit
