*PADS-LIBRARY-PART-TYPES-V9*

SN74ABT245BDWR SOIC127P1030X265-20N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.11.22.40.45
"Mouser Part Number" 595-SN74ABT245BDWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74ABT245BDWR?qs=afYny40WCj1jrBby8G5Ixw%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74ABT245BDWR
"Description" Texas Instruments SN74ABT245BDWR, Bus Transceiver, 8-Bit Non-Inverting TTL, 5V, 20-Pin SOIC
"Datasheet Link" http://www.ti.com/lit/gpn/sn74abt245b
"Geometry.Height" 2.65mm
GATE 1 20 0
SN74ABT245BDWR
1 0 U DIR
2 0 U A1
3 0 U A2
4 0 U A3
5 0 U A4
6 0 U A5
7 0 U A6
8 0 U A7
9 0 U A8
10 0 U GND
20 0 U VCC
19 0 U \OE
18 0 U B1
17 0 U B2
16 0 U B3
15 0 U B4
14 0 U B5
13 0 U B6
12 0 U B7
11 0 U B8

*END*
*REMARK* SamacSys ECAD Model
415977/1410301/2.50/20/3/Integrated Circuit
