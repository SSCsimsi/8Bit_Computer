*PADS-LIBRARY-PART-TYPES-V9*

SN74AHC157DR SOIC127P600X175-16N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.23.51.44
"Mouser Part Number" 595-SN74AHC157DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AHC157DR?qs=nMmhAzRCgdCMVxhGfqxf9A%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHC157DR
"Description" Quadruple 2-Line To 1-Line Data Selectors / Multiplexers
"Datasheet Link" http://www.ti.com/lit/gpn/sn74ahc157
"Geometry.Height" 1.75mm
GATE 1 16 0
SN74AHC157DR
1 0 L \A\/B
2 0 L 1A
3 0 L 1B
4 0 S 1Y
5 0 L 2A
6 0 L 2B
7 0 S 2Y
8 0 G GND
16 0 P VCC
15 0 L \G
14 0 L 4A
13 0 L 4B
12 0 S 4Y
11 0 L 3A
10 0 L 3B
9 0 S 3Y

*END*
*REMARK* SamacSys ECAD Model
752119/1410301/2.50/16/3/Integrated Circuit
