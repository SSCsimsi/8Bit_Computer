*PADS-LIBRARY-PART-TYPES-V9*

LTST-C171TBKT LTSTC171TBKT I DIO 7 1 0 0 0
TIMESTAMP 2025.10.27.15.46.24
"Mouser Part Number" 859-LTST-C171TBKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Lite-On/LTST-C171TBKT?qs=DIGZ1Yxiz2%2FRYShBNqRoMg%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C171TBKT
"Description" LED,SMD,0805,Blue,28mcd,130deg Lite-On LTST-C171TBKT, CHIPLED 0805 Series Blue LED, 475 nm 2012 (0805), Rectangle Lens SMD package
"Datasheet Link" https://optoelectronics.liteon.com/upload/download/DS22-2000-233/LTST-C171TBKT(0630).pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
LTST-C171TBKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
612576/1410301/2.50/2/3/LED
