*PADS-LIBRARY-PART-TYPES-V9*

LTST-C171KSKT LTSTC171KSKT I DIO 7 1 0 0 0
TIMESTAMP 2025.10.27.15.46.21
"Mouser Part Number" 859-LTST-C171KSKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/LITEON/LTST-C171KSKT?qs=llMtm9xcdM0CwR1bByTaUQ%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C171KSKT
"Description" Yellow 587nm LED Indication - Discrete 2V 0805 (2012 Metric)
"Datasheet Link" https://optoelectronics.liteon.com/upload/download/DS22-2000-110/LTST-C171KSKT.pdf
"Geometry.Height" 0.9mm
GATE 1 2 0
LTST-C171KSKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
278905/1410301/2.50/2/3/LED
