*PADS-LIBRARY-PART-TYPES-V9*

M20-8890845 M208890845 I CON 6 1 0 0 0
TIMESTAMP 2025.10.25.11.42.51
"Mouser Part Number" 855-M20-8890845
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-8890845?qs=k41KVqW3ymqbj55BP%2FIx8Q%3D%3D
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-8890845
"Description" 2.54mm (0.1") Pitch SIL SMT Horizontal Pin Header, 2.5mm housing height, gold, 8 contacts
"Datasheet Link" https://cdn.harwin.com/pdfs/M20-889.pdf
GATE 1 8 0
M20-8890845
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5
6 0 U 6
7 0 U 7
8 0 U 8

*END*
*REMARK* SamacSys ECAD Model
1166802/1410301/2.50/8/2/Connector
