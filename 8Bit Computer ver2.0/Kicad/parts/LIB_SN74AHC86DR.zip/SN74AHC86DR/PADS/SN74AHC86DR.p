*PADS-LIBRARY-PART-TYPES-V9*

SN74AHC86DR SOIC127P600X175-14N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.18.59.26
"Mouser Part Number" 595-SN74AHC86DR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74AHC86DR?qs=D5pVkbrsqqK0yvWJ8LFETg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74AHC86DR
"Description" Quadruple 2-Input Exclusive-OR Gates
"Datasheet Link" http://www.ti.com/lit/gpn/sn74ahc86
"Geometry.Height" 1.75mm
GATE 1 14 0
SN74AHC86DR
1 0 U 1A
2 0 U 1B
3 0 U 1Y
4 0 U 2A
5 0 U 2B
6 0 U 2Y
7 0 U GND
14 0 U VCC
13 0 U 4B
12 0 U 4A
11 0 U 4Y
10 0 U 3B
9 0 U 3A
8 0 U 3Y

*END*
*REMARK* SamacSys ECAD Model
754717/1410301/2.50/14/3/Integrated Circuit
