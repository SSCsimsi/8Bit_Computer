*PADS-LIBRARY-PART-TYPES-V9*

DS1100Z-20+ SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.25.11.42.34
"Mouser Part Number" 700-DS1100Z-20
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Analog-Devices-Maxim-Integrated/DS1100Z-20%2b?qs=0Y9aZN%252BMVCX5CJKJjF7c1Q%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" DS1100Z-20+
"Description" DS1100Z-20+, Delay Line, 5-Taps 500ns, 8-Pin SOIC
"Datasheet Link" https://datasheets.maximintegrated.com/en/ds/DS1100.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
DS1100Z-20+
1 0 U IN
2 0 U TAP_2
3 0 U TAP_4
4 0 U GND
8 0 U VCC
7 0 U TAP_1
6 0 U TAP_3
5 0 U TAP_5

*END*
*REMARK* SamacSys ECAD Model
387362/1410301/2.50/8/3/Integrated Circuit
