*PADS-LIBRARY-PART-TYPES-V9*

DS1100Z-150+ SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.29.13.59.28
"Mouser Part Number" 700-DS1100Z-150
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Maxim-Integrated/DS1100Z-150%2b?qs=Jw2w9zrI6w9cWpTP9DBTEQ%3D%3D
"Manufacturer_Name" Analog Devices
"Manufacturer_Part_Number" DS1100Z-150+
"Description" Delay Lines / Timing Elements 5-Tap Economy Timing Element (Delay Line)
"Datasheet Link" https://datasheets.maximintegrated.com/en/ds/DS1100.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
DS1100Z-150+
1 0 U IN
2 0 U TAP_2
3 0 U TAP_4
4 0 U GND
8 0 U VCC
7 0 U TAP_1
6 0 U TAP_3
5 0 U TAP_5

*END*
*REMARK* SamacSys ECAD Model
696671/1410301/2.50/8/3/Integrated Circuit
