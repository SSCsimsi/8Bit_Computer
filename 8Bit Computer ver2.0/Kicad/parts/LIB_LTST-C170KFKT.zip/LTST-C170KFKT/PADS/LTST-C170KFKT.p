*PADS-LIBRARY-PART-TYPES-V9*

LTST-C170KFKT LEDC2012X120N I DIO 7 1 0 0 0
TIMESTAMP 2025.10.27.15.46.05
"Mouser Part Number" 859-LTST-C170KFKT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Lite-On/LTST-C170KFKT?qs=gKd32bbgGM%2FWUWN9MKaKoA%3D%3D
"Manufacturer_Name" Lite-On
"Manufacturer_Part_Number" LTST-C170KFKT
"Description" Standard LEDs - SMD Orange Clear 605nm
"Datasheet Link" http://optoelectronics.liteon.com/upload/download/DS-22-99-0185/LTST-C170KFKT.pdf
"Geometry.Height" 1.2mm
GATE 1 2 0
LTST-C170KFKT
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
715379/1410301/2.50/2/3/LED
