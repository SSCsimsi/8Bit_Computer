*PADS-LIBRARY-PART-TYPES-V9*

B3FS-4055P B3FS4055P I SWI 7 1 0 0 0
TIMESTAMP 2025.10.29.14.41.41
"Mouser Part Number" 653-B3FS-4055P
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Omron-Electronics/B3FS-4055P?qs=8Kz9Wu9QwqWEoBxnkyUN7A%3D%3D
"Manufacturer_Name" OMRON Electronics
"Manufacturer_Part_Number" B3FS-4055P
"Description" Switch Tactile N.O. SPST Projected Plunger Gull Wing 0.05A 24VDC 2.55N SMD T/R
"Datasheet Link" https://omronfs.omron.com/en_US/ecb/products/pdf/en-b3fs_4.pdf
"Geometry.Height" 7.3mm
GATE 1 4 0
B3FS-4055P
1 0 U COM_1
2 0 U COM_2
3 0 U NO_1
4 0 U NO_2

*END*
*REMARK* SamacSys ECAD Model
956549/1410301/2.50/4/3/Switch
