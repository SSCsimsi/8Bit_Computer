*PADS-LIBRARY-PART-TYPES-V9*

SN74HC682N DIP794W53P254L2540H508Q20N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.10.18.59.58
"Mouser Part Number" 595-SN74HC682N
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74HC682N?qs=JD1fk4stihZ5fZizX5ugBQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74HC682N
"Description" Magnitude Comparator 8-Bit 20-Pin PDIP
"Datasheet Link" http://www.ti.com/lit/gpn/sn74hc682
"Geometry.Height" 5.08mm
GATE 1 20 0
SN74HC682N
1 0 U \P>Q
2 0 U P0
3 0 U Q0
4 0 U P1
5 0 U Q1
6 0 U P2
7 0 U Q2
8 0 U P3
9 0 U Q3
10 0 U GND
20 0 U VCC
19 0 U \P=Q
18 0 U Q7
17 0 U P7
16 0 U Q6
15 0 U P6
14 0 U Q5
13 0 U P5
12 0 U Q4
11 0 U P4

*END*
*REMARK* SamacSys ECAD Model
182001/1410301/2.50/20/0/Integrated Circuit
