*PADS-LIBRARY-PART-TYPES-V9*

2MS1T2B3M2QES 2MS1T2B3M2QES I SWI 7 1 0 0 0
TIMESTAMP 2025.10.28.20.57.03
"Mouser Part Number" 118-2MS1T2B3M2QES
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Dailywell/2MS1T2B3M2QES?qs=B6kkDfuK7%2FA47d%2FxOCDsrA%3D%3D
"Manufacturer_Name" Dailywell
"Manufacturer_Part_Number" 2MS1T2B3M2QES
"Description" Toggle Switches SPDT ON-ON PC MOUNT
"Datasheet Link" 
"Geometry.Height" 19.56mm
GATE 1 3 0
2MS1T2B3M2QES
1 0 U NO
2 0 U COM
3 0 U NC

*END*
*REMARK* SamacSys ECAD Model
12984514/1410301/2.50/3/3/Switch
