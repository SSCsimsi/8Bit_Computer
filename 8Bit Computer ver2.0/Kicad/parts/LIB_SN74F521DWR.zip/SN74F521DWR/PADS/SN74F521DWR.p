*PADS-LIBRARY-PART-TYPES-V9*

SN74F521DWR SOIC127P1030X265-20N I ANA 7 1 0 0 0
TIMESTAMP 2025.10.12.00.06.22
"Mouser Part Number" 595-SN74F521DWR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/SN74F521DWR?qs=mE33ZKBHyE6Hxf0oNfiDUg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" SN74F521DWR
"Description" 8-Bit Identity/Magnitude Comparators (P=Q) with Enable
"Datasheet Link" http://www.ti.com/lit/gpn/sn74f521
"Geometry.Height" 2.65mm
GATE 1 20 0
SN74F521DWR
1 0 U \OE
2 0 U P0
3 0 U Q0
4 0 U P1
5 0 U Q1
6 0 U P2
7 0 U Q2
8 0 U P3
9 0 U Q3
10 0 U GND
20 0 U VCC
19 0 U \P_=_Q
18 0 U Q7
17 0 U P7
16 0 U Q6
15 0 U P6
14 0 U Q5
13 0 U P5
12 0 U Q4
11 0 U P4

*END*
*REMARK* SamacSys ECAD Model
752331/1410301/2.50/20/3/Integrated Circuit
